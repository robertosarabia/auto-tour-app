package com.example.android.miwok;

import android.location.Location;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class CleanFragment extends Fragment {

    public CleanFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.location_list, container, false);

        // Create a list of locations
        final ArrayList<Location> locations = new ArrayList<Location>();
        locations.add(new Location("Detail Maniac", "6320 Belleau Wood Ln Ste 3 Sacramento, CA", "(916) 304-2929", R.drawable.ic_bubble_chart));
        locations.add(new Location("Hayes Detail", "1876 Stockton Blvd Sacramento, CA", "(916) 719-7759", R.drawable.ic_bubble_chart));
        locations.add(new Location("JR Auto Detailing", "2520 Walnut Ave Carmichael, CA", "(916) 488-1541", R.drawable.ic_bubble_chart));
        locations.add(new Location("Pavilion Car Care", "2334 Fair Oaks Blvd Sacramento, CA", "(916) 925-8533", R.drawable.ic_bubble_chart));
        locations.add(new Location("House of Bling Bling", "2520 Northgate Blvd Sacramento, CA", "(916) 649-0334", R.drawable.ic_bubble_chart));
        locations.add(new Location("Kelly’s Express Car Wash", "7664 Stockton Blvd Sacramento, CA", "(916) 688-7090", R.drawable.ic_bubble_chart));
        locations.add(new Location("Quick Quack Car Wash", "1609 Watt Ave Sacramento, CA", "(916) 760-8701", R.drawable.ic_bubble_chart));

        // Create an {@link LocationAdapter}, whose data source is a list of {@link Location}s. The
        // adapter knows how to create list items for each item in the list.
        LocationAdapter adapter = new LocationAdapter(getActivity(), locations, R.color.category_clean);

        // Find the {@link ListView} object in the view hierarchy of the {@link Activity}.
        // There should be a {@link ListView} with the view ID called list, which is declared in the
        // word_list.xml file.
        ListView listView = (ListView) rootView.findViewById(R.id.list);

        // Make the {@link ListView} use the {@link WordAdapter} created above, so that the
        // {@link ListView} will display list items for each {@link Word} in the list.
        listView.setAdapter(adapter);

        return rootView;
    }
}